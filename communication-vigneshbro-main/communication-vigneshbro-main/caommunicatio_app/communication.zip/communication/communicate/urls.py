


from .views import smsfunction,emailfunction,watsappmsgfunction
from django.urls import include, path
#watsappemailfunction
urlpatterns = [


               path('sms/',smsfunction.as_view(), name="Sms"),
               path('email/',emailfunction.as_view(), name="Email"),
               path('watsappmsg/',watsappmsgfunction.as_view(), name="Watsappmsg"),
  
   
             ]
