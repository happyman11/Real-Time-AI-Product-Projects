

from .serializers import (
                                sms_Serializer,
                                Email_Serializer,
                                watsapp_Serializer
                         )

from .models import (
                        Sms_detail,
                        Email_detail,
                        Watsapp_detail         
                    )


import re
from django.conf import settings
from django.shortcuts import render
from rest_framework.views import APIView
from  .sms_function import Dishpatcher_sms
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.mail import send_mail,EmailMultiAlternatives
from rest_framework.authentication import SessionAuthentication, BasicAuthentication




class smsfunction(APIView):


    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]

    serializer_class=sms_Serializer

    def post(self, request, format=None):

        Country_code =  request.data.get('Countrycode')
        phone_number =  request.data.get('Number')
        content      =  request.data.get('Content')

        if phone_number and content and Country_code:

            if len(str(phone_number)) == 10:

                
                reciever_number=str(Country_code)+str(phone_number)
                
                sms_class=Dishpatcher_sms()
                send_sms=sms_class.send_sms_twillio( content,reciever_number)

                sms_data=Sms_detail(
                                        Number   =reciever_number,
                                        Content  =content,
                                        msgid    =send_sms["sms.sid"],
                                        status   =send_sms["response"]
                                   )

                sms_data.save()
             
                
                return Response(send_sms)

            else:

                if len(str(phone_number)) >10:
                    
                    reciever_number=str(Country_code)+str(phone_number)
                    sms_data=Sms_detail(
                                             Number  =reciever_number,
                                             Content =content,
                                             msgid   ="None",
                                             status  ="Please check the input Number (more than 10)"
                                       )

                    sms_data.save()

                    dev                  = {}
                    dev["response"]      = "Please check the input Number (more than 10)"
                    dev["Provided By:"]  = "Chadura Communication Api Services"
                    dev["status"]        =  400
                    
                    return Response(dev)
                
                else:

                    reciever_number=str(Country_code )+str(phone_number)
                    sms_data=Sms_detail(
                                          Number   =reciever_number,
                                          Content  =content,
                                          msgid    ="None",
                                          status   ="Please check the input Number (less than 10)"

                                       )

                    sms_data.save()

                    dev                   = {}
                    dev["response"]       = "Please check the input Number (less than 10)"
                    dev["Provided By:"]   = "Chadura Communication Api Services"
                    dev["status"]         =  400
                    
                    return Response(dev)




        else:
                 
                reciever_number=str(Country_code )+str(phone_number)
                sms_data=Sms_detail(
                                         
                                         Number   =reciever_number,
                                         Content  =content,
                                         msgid    ="None",
                                         status   ="Input Arguments is empty"

                                   )

                sms_data.save()
               
              
                dev                     = {}
                dev["response"]         = "Input Arguments is empty"
                dev["Provided By:"]     = "Chadura Communication Api Services"
                dev["status"]           = 400
                
                return Response(dev)




class emailfunction(APIView):



    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]

    serializer_class=Email_Serializer

    def post(self, request, format=None):


        reciepient  =  request.data.get('reciepient')
        subject     =  request.data.get('subject')
        Content     =  request.data.get('Content')

        if reciepient and subject and Content :

            email_Searched = re.search(r'[\w.+-]+@[\w-]+\.[\w.-]+', str(reciepient), flags=0) 
            
            if email_Searched:

                
                
                try:

                    msg                 = EmailMultiAlternatives(subject,Content, settings.EMAIL_HOST_USER, [reciepient])
                    msg.content_subtype = "html"  
                    msg.send()

                    Email_data =Email_detail(
                                                reciepient  = reciepient,
                                                subject     = subject,
                                                Content     = Content,
                                                status      = "Mail Sent Successfully"                              
                                            )

                

                    Email_data.save()
                
            
                    dev                  = {}
                    dev["response"]      = "Mail Sent Successfully"
                    dev["Provided By:"]  = "Chadura Communication Api Services"
                    dev["status"]        =  200
                    
                    return Response(dev)


                except:

                    Email_data =Email_detail(
                                                reciepient  = reciepient,
                                                subject     = subject,
                                                Content     = Content,
                                                status      = "Mail Sending Failed"                              
                                            )

                

                    Email_data.save()
                
            
                    dev                  =   {}
                    dev["response"]      =   "Mail Sending Failed"
                    dev["Provided By:"]  =   "Chadura Communication Api Services"
                    dev["status"]        =   400
                    
                    return Response(dev)


            else:


                Email_data =Email_detail (
                                            
                                            reciepient  =  reciepient,
                                            subject     =  subject,
                                            Content     =  Content,
                                            status      =  "Email is missing in recipient email"   

                                         )

                Email_data.save()


            
                dev                  =   {}
                dev["response"]      =  "Email is missing in recipient email" 
                dev["Provided By:"]  =  "Chadura Communication Api Services"
                dev["status"]        =   400
                
                return Response(dev)



        else:


            Email_data =Email_detail(
                                      
                                      reciepient  =  reciepient,
                                      subject     =  subject,
                                      Content     =  Content,
                                      status      =  "Input Arguments is empty"

                                    )

            Email_data.save()

            dev                  =   {}
            dev["response"]      =   "Input Arguments is empty"
            dev["Provided By:"]  =   "Chadura Communication Api Services"
            dev["status"]        =   400
            
            return Response(dev)


class watsappmsgfunction(APIView):

    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAuthenticated]

    serializer_class=watsapp_Serializer
   
    

    def post(self, request, format=None):

       
        phone_number =  request.data.get('Number')
        content      =  request.data.get('Content')

        if phone_number and content :

            if len(str(phone_number)) == 10:

                
                reciever_number="+91"+str(phone_number)
                
                sms_class=Dishpatcher_sms()
                send_sms=sms_class.send_watsappsms_twillio( content,reciever_number)

                sms_data=Watsapp_detail(
                                        Number   =reciever_number,
                                        Content  =content,
                                        msgid    =send_sms["sms.sid"],
                                        status   =send_sms["response"]
                                   )

                sms_data.save()
             
                
                return Response(send_sms)

            else:

                if len(str(phone_number)) >10:
                    
                    reciever_number="+91"+str(phone_number)
                    sms_data=Watsapp_detail(
                                             Number  =reciever_number,
                                             Content =content,
                                             msgid   ="None",
                                             status  ="Please check the input Number (more than 10)"
                                       )

                    sms_data.save()

                    dev                  = {}
                    dev["response"]      = "Please check the input Number (more than 10)"
                    dev["Provided By:"]  = "Chadura Communication Api Services"
                    dev["status"]        =  400
                    
                    return Response(dev)
                
                else:

                    reciever_number="+91"+str(phone_number)
                    sms_data=Watsapp_detail(
                                          Number   =reciever_number,
                                          Content  =content,
                                          msgid    ="None",
                                          status   ="Please check the input Number (less than 10)"

                                       )

                    sms_data.save()

                    dev                   = {}
                    dev["response"]       = "Please check the input Number (less than 10)"
                    dev["Provided By:"]   = "Chadura Communication Api Services"
                    dev["status"]         =  400
                    
                    return Response(dev)




        else:
                 
                reciever_number="+91"+str(phone_number)
                sms_data=Watsapp_detail(
                                         
                                         Number   =reciever_number,
                                         Content  =content,
                                         msgid    ="None",
                                         status   ="Input Arguments is empty"

                                   )

                sms_data.save()
               
              
                dev                     = {}
                dev["response"]         = "Input Arguments is empty"
                dev["Provided By:"]     = "Chadura Communication Api Services"
                dev["status"]           = 400
                
                return Response(dev)










       
        














        

        

