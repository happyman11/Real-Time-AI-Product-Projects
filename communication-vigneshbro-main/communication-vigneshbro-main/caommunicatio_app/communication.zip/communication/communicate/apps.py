from django.apps import AppConfig


class CommunicateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'communicate'
